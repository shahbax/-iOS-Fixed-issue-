class GrantType {
  static const String authorizationCode = 'authorization_code';
  static const String refreshToken = 'refresh_token';
  static const String implicit = 'implicit';
}
