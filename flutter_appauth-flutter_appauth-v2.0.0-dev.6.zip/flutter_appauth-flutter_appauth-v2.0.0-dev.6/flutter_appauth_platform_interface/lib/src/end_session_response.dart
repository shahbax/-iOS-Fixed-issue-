class EndSessionResponse {
  final String? state;

  EndSessionResponse(this.state);
}
