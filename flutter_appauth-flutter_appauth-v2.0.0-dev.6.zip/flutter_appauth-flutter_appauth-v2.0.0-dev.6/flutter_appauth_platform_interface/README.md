# flutter_appauth_platform_interface

[![pub package](https://img.shields.io/pub/v/flutter_appauth_platform_interface.svg)](https://pub.dartlang.org/packages/flutter_appauth_platform_interface)

A common platform interface for the [`flutter_appauth`](https://pub.dev/packages/flutter_appauth) plugin.